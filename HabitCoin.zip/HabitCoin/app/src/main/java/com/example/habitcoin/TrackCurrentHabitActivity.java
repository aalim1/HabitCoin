package com.example.habitcoin;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TrackCurrentHabitActivity extends AppCompatActivity {
    TextView habitInput;
    TextView moneyInput;
    String habInput;
    String monInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_current_habit);

        habitInput=findViewById(R.id.habitInputTest);
        moneyInput=findViewById(R.id.moneyInputTest);

        habInput = getIntent().getExtras().getString("Habit");
        monInput = getIntent().getExtras().getString("Money");

        habitInput.setText(habInput);
        moneyInput.setText(monInput);
    }
}
