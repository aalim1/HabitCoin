package com.example.habitcoin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    //Declare Variables
    private Button newHabitBtn;
    private Button trackCurrentBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newHabitBtn = (Button)findViewById(R.id.newHabitBtn);
        newHabitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent (getApplicationContext(), StartNewHabitActivity.class);
                startActivity(startIntent);
            }
        });

        trackCurrentBtn = (Button)findViewById(R.id.trackCurrentBtn);
        trackCurrentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent1 = new Intent (getApplicationContext(), TrackCurrentHabitActivity.class);
                startActivity(startIntent1);
            }
        });
    }
}
