package com.example.habitcoin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class StartNewHabitActivity extends AppCompatActivity {
    String habCreate;
    String habMoney;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_new_habit);

        //Declare Variables
        Button createHabitBtn = (Button) findViewById(R.id.createHabitBtn);
        createHabitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(StartNewHabitActivity.this, TrackCurrentHabitActivity.class);
                EditText habitCreatorEditText = (EditText) findViewById(R.id.habitCreatorEditText);
                habCreate = habitCreatorEditText.getText().toString();
                i.putExtra("Habit", habCreate);
                startActivity(i);
                finish();
            }
        });

        Button moneyAmtBtn = (Button) findViewById(R.id.moneyAmtBtn);
        moneyAmtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(StartNewHabitActivity.this, TrackCurrentHabitActivity.class);
                EditText habitMoneyEditText = (EditText) findViewById(R.id.habitMoneyEditText);
                habMoney = habitMoneyEditText.getText().toString();
                i2.putExtra("Money", habMoney);
                startActivity(i2);
                finish();
            }
        });
    }
}
